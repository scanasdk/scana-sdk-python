from distutils.core import setup
setup(
    name='pyscanasdk',
    packages=['pyscanasdk'],
    version='1.0.5',
    license='MIT',
    description='Type your package description',
    author='scana',
    author_email='scanaservice@knownsec.com',
    install_requires=[
        'requests',
    ],
)